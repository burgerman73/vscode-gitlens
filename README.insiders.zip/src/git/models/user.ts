'use strict';

export interface GitUser {
	name: string | undefined;
	email: string | undefined;
}
